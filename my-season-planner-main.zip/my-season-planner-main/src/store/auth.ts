import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { User, SportType } from "@/lib/types";

const SEED_USERS: User[] = [
  {
    id: "user-admin",
    name: "Admin User",
    email: "admin@myseason.pro",
    avatar: "https://api.dicebear.com/7.x/initials/svg?seed=Admin",
    country: "Lithuania",
    city: "Vilnius",
    bio: "Platform admin & ultra runner.",
    favorite_sports: ["running", "triathlon"],
    role: "admin",
  },
  {
    id: "user-2",
    name: "Elena Marks",
    email: "elena@example.com",
    avatar: "https://api.dicebear.com/7.x/initials/svg?seed=Elena+Marks",
    country: "Germany",
    city: "Berlin",
    bio: "Marathon hunter chasing all six majors.",
    favorite_sports: ["running"],
    role: "user",
  },
];

interface AuthState {
  currentUserId: string | null;
  users: User[];
  login: (email: string) => User | null;
  signup: (name: string, email: string) => User;
  logout: () => void;
  updateUser: (patch: Partial<User>) => void;
  getUser: (id: string | null) => User | undefined;
}

export const useAuth = create<AuthState>()(
  persist(
    (set, get) => ({
      currentUserId: null,
      users: SEED_USERS,
      login: (email) => {
        const user = get().users.find((u) => u.email.toLowerCase() === email.toLowerCase());
        if (user) set({ currentUserId: user.id });
        return user ?? null;
      },
      signup: (name, email) => {
        const existing = get().users.find((u) => u.email.toLowerCase() === email.toLowerCase());
        if (existing) {
          set({ currentUserId: existing.id });
          return existing;
        }
        const user: User = {
          id: `user-${Date.now()}`,
          name,
          email,
          avatar: `https://api.dicebear.com/7.x/initials/svg?seed=${encodeURIComponent(name)}`,
          country: "",
          city: "",
          bio: "",
          favorite_sports: [] as SportType[],
          role: "user",
        };
        set({ users: [...get().users, user], currentUserId: user.id });
        return user;
      },
      logout: () => set({ currentUserId: null }),
      updateUser: (patch) => {
        const id = get().currentUserId;
        if (!id) return;
        set({ users: get().users.map((u) => (u.id === id ? { ...u, ...patch } : u)) });
      },
      getUser: (id) => (id ? get().users.find((u) => u.id === id) : undefined),
    }),
    { name: "myseason-auth" },
  ),
);

export const useCurrentUser = () => {
  const { currentUserId, users } = useAuth();
  return users.find((u) => u.id === currentUserId) ?? null;
};
