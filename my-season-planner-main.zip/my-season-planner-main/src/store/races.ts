import { useMemo } from "react";
import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Race, RaceStatus, RaceType } from "@/lib/types";
import { SEED_RACES } from "@/data/races";

interface RacesState {
  races: Race[];
  addRace: (race: Omit<Race, "id" | "created_at" | "status" | "popularity_score"> & { race_type: RaceType }) => Race;
  updateRace: (id: string, patch: Partial<Race>) => void;
  setStatus: (id: string, status: RaceStatus) => void;
  removeRace: (id: string) => void;
  promoteToOfficial: (id: string) => void;
  reset: () => void;
}

export const useRaces = create<RacesState>()(
  persist(
    (set, get) => ({
      races: SEED_RACES,
      addRace: (input) => {
        const race: Race = {
          ...input,
          id: `race-${Date.now()}`,
          created_at: new Date().toISOString(),
          status: input.race_type === "community" ? "approved" : "pending",
          popularity_score: 0,
        };
        set({ races: [race, ...get().races] });
        return race;
      },
      updateRace: (id, patch) =>
        set({ races: get().races.map((r) => (r.id === id ? { ...r, ...patch } : r)) }),
      setStatus: (id, status) =>
        set({ races: get().races.map((r) => (r.id === id ? { ...r, status } : r)) }),
      removeRace: (id) => set({ races: get().races.filter((r) => r.id !== id) }),
      promoteToOfficial: (id) =>
        set({
          races: get().races.map((r) =>
            r.id === id ? { ...r, race_type: "official", status: "approved" } : r,
          ),
        }),
      reset: () => set({ races: SEED_RACES }),
    }),
    { name: "myseason-races", version: 1 },
  ),
);

export const useApprovedRaces = () => {
  const races = useRaces((s) => s.races);
  return useMemo(() => races.filter((r) => r.status === "approved"), [races]);
};
