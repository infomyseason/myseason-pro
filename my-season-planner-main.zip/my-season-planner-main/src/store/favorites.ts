import { create } from "zustand";
import { persist } from "zustand/middleware";
import type { Favorite } from "@/lib/types";

const EMPTY: Favorite[] = [];

interface FavoritesState {
  // keyed by userId
  byUser: Record<string, Favorite[]>;
  toggle: (userId: string, raceId: string, defaultDistance: string) => void;
  setDistance: (userId: string, raceId: string, distance: string) => void;
  setCompleted: (userId: string, raceId: string, completed: boolean) => void;
  remove: (userId: string, raceId: string) => void;
  forUser: (userId: string | null | undefined) => Favorite[];
  has: (userId: string | null | undefined, raceId: string) => boolean;
  get: (userId: string | null | undefined, raceId: string) => Favorite | undefined;
}

export const useFavorites = create<FavoritesState>()(
  persist(
    (set, get) => ({
      byUser: {},
      toggle: (userId, raceId, defaultDistance) => {
        const list = get().byUser[userId] ?? [];
        const existing = list.find((f) => f.race_id === raceId);
        const next = existing
          ? list.filter((f) => f.race_id !== raceId)
          : [...list, { race_id: raceId, selected_distance: defaultDistance, completed: false, added_at: new Date().toISOString() }];
        set({ byUser: { ...get().byUser, [userId]: next } });
      },
      setDistance: (userId, raceId, distance) => {
        const list = get().byUser[userId] ?? [];
        set({
          byUser: {
            ...get().byUser,
            [userId]: list.map((f) => (f.race_id === raceId ? { ...f, selected_distance: distance } : f)),
          },
        });
      },
      setCompleted: (userId, raceId, completed) => {
        const list = get().byUser[userId] ?? [];
        set({
          byUser: {
            ...get().byUser,
            [userId]: list.map((f) => (f.race_id === raceId ? { ...f, completed } : f)),
          },
        });
      },
      remove: (userId, raceId) => {
        const list = get().byUser[userId] ?? [];
        set({ byUser: { ...get().byUser, [userId]: list.filter((f) => f.race_id !== raceId) } });
      },
      forUser: (userId) => (userId ? get().byUser[userId] ?? EMPTY : EMPTY),
      has: (userId, raceId) =>
        !!userId && !!(get().byUser[userId] ?? []).find((f) => f.race_id === raceId),
      get: (userId, raceId) =>
        userId ? (get().byUser[userId] ?? []).find((f) => f.race_id === raceId) : undefined,
    }),
    { name: "myseason-favorites" },
  ),
);
