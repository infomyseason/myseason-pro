import { create } from "zustand";
import { persist } from "zustand/middleware";

interface LocationState {
  country: string | null;
  setCountry: (c: string | null) => void;
}

export const useUserLocation = create<LocationState>()(
  persist(
    (set) => ({
      country: null,
      setCountry: (country) => set({ country }),
    }),
    { name: "myseason-location" },
  ),
);
