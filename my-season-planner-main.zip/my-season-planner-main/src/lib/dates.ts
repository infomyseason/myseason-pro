import { differenceInCalendarDays } from "date-fns";

export function daysUntil(iso: string): number {
  return differenceInCalendarDays(new Date(iso), new Date());
}

export function timeRemainingLabel(iso: string): string {
  const d = daysUntil(iso);
  if (d < 0) return `${Math.abs(d)}d ago`;
  if (d === 0) return "Today";
  if (d === 1) return "Tomorrow";
  if (d < 14) return `${d} days`;
  if (d < 60) return `${Math.round(d / 7)} weeks`;
  return `${Math.round(d / 30)} months`;
}
