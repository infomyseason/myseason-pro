export type SportType = "running" | "triathlon" | "cycling" | "hyrox";

export type RunningSubcategory =
  | "5K" | "10K" | "Half Marathon" | "Marathon" | "30K" | "Ultra" | "Trail" | "Road" | "Other";
export type TriathlonSubcategory =
  | "Sprint" | "Olympic" | "T100" | "IM 70.3" | "Ironman" | "Local" | "Other";
export type CyclingSubcategory =
  | "Road" | "Gravel" | "MTB" | "Gran Fondo" | "Time Trial" | "Other";
export type HyroxSubcategory =
  | "Individual" | "Doubles" | "Relay" | "Pro" | "Open";

export type Subcategory =
  | RunningSubcategory | TriathlonSubcategory | CyclingSubcategory | HyroxSubcategory;

export type RaceType = "official" | "community";
export type RaceStatus = "pending" | "approved" | "rejected";

export interface Race {
  id: string;
  title: string;
  sport_type: SportType;
  subcategory: Subcategory;
  country: string;
  city: string;
  date: string; // ISO
  distances: string[];
  description: string;
  official_website_url: string;
  race_type: RaceType;
  status: RaceStatus;
  popularity_score: number;
  created_by: string;
  created_at: string;
}

export interface User {
  id: string;
  name: string;
  email: string;
  avatar: string;
  country: string;
  city: string;
  bio: string;
  favorite_sports: SportType[];
  role: "user" | "admin";
}

export interface Favorite {
  race_id: string;
  selected_distance: string;
  completed: boolean;
  added_at: string;
}
