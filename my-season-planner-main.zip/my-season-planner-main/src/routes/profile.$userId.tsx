import { createFileRoute } from "@tanstack/react-router";
import { ProfileView } from "@/components/ProfileView";

export const Route = createFileRoute("/profile/$userId")({
  head: () => ({ meta: [{ title: "Athlete profile | myseason.pro" }] }),
  component: PublicProfile,
});

function PublicProfile() {
  const { userId } = Route.useParams();
  return <ProfileView userId={userId} editable={false} />;
}
