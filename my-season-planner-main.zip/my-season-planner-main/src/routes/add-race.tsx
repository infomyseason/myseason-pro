import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { SPORTS } from "@/data/sports";
import { EUROPEAN_COUNTRIES } from "@/data/countries";
import { useRaces } from "@/store/races";
import { useCurrentUser } from "@/store/auth";
import type { SportType, Subcategory } from "@/lib/types";
import { toast } from "sonner";
import { ShieldCheck, Users } from "lucide-react";
import { cn } from "@/lib/utils";

export const Route = createFileRoute("/add-race")({
  head: () => ({ meta: [{ title: "Add a race | myseason.pro" }] }),
  component: AddRacePage,
});

function AddRacePage() {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const addRace = useRaces((s) => s.addRace);

  const [title, setTitle] = useState("");
  const [sport, setSport] = useState<SportType>("running");
  const [subcategory, setSubcategory] = useState<Subcategory>(SPORTS.running.subcategories[0]);
  const [country, setCountry] = useState("");
  const [city, setCity] = useState("");
  const [date, setDate] = useState("");
  const [distancesInput, setDistancesInput] = useState("");
  const [description, setDescription] = useState("");
  const [url, setUrl] = useState("");
  const [raceType, setRaceType] = useState<"official" | "community">("community");

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-24 text-center max-w-md">
        <h1 className="font-display text-3xl font-bold">Sign in to add a race</h1>
        <p className="text-muted-foreground mt-2">You need an account to submit races.</p>
        <Button asChild className="mt-6"><Link to="/login">Sign in</Link></Button>
      </div>
    );
  }

  const submit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!title || !country || !city || !date || !description || !url) {
      toast.error("Please fill in all fields");
      return;
    }
    const distances = distancesInput
      .split(",").map((d) => d.trim()).filter(Boolean);
    if (distances.length === 0) {
      toast.error("Add at least one distance");
      return;
    }
    const race = addRace({
      title, sport_type: sport, subcategory, country, city,
      date: new Date(date).toISOString(),
      distances, description,
      official_website_url: url,
      race_type: raceType,
      created_by: user.id,
    });
    if (raceType === "community") {
      toast.success("Community race published!");
      navigate({ to: "/events/$raceId", params: { raceId: race.id } });
    } else {
      toast.success("Submitted for admin approval");
      navigate({ to: "/profile" });
    }
  };

  return (
    <div className="container mx-auto px-4 py-10 max-w-2xl">
      <h1 className="font-display text-3xl md:text-4xl font-bold">Add a race</h1>
      <p className="text-muted-foreground mt-1">Help the community discover more events.</p>

      <form onSubmit={submit} className="mt-8 space-y-6 rounded-2xl border border-border bg-card p-6">
        <div className="grid grid-cols-2 gap-3">
          {(["community", "official"] as const).map((t) => {
            const Icon = t === "official" ? ShieldCheck : Users;
            const active = raceType === t;
            return (
              <button
                key={t}
                type="button"
                onClick={() => setRaceType(t)}
                className={cn(
                  "p-4 rounded-xl border text-left transition-colors",
                  active ? "border-primary bg-primary/10" : "border-border hover:border-foreground/30",
                )}
              >
                <Icon className={cn("w-5 h-5 mb-2", active ? "text-primary" : "text-muted-foreground")} />
                <div className="font-semibold text-sm capitalize">{t} race</div>
                <div className="text-xs text-muted-foreground mt-1">
                  {t === "community"
                    ? "Published instantly. Open to anyone."
                    : "Reviewed by an admin before publishing."}
                </div>
              </button>
            );
          })}
        </div>

        <Field label="Title">
          <Input value={title} onChange={(e) => setTitle(e.target.value)} placeholder="Vilnius Marathon" />
        </Field>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Sport">
            <Select value={sport} onValueChange={(v) => {
              const s = v as SportType;
              setSport(s);
              setSubcategory(SPORTS[s].subcategories[0]);
            }}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {Object.values(SPORTS).map((s) => <SelectItem key={s.id} value={s.id}>{s.label}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="Subcategory">
            <Select value={subcategory} onValueChange={(v) => setSubcategory(v as Subcategory)}>
              <SelectTrigger><SelectValue /></SelectTrigger>
              <SelectContent>
                {SPORTS[sport].subcategories.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Country">
            <Select value={country} onValueChange={setCountry}>
              <SelectTrigger><SelectValue placeholder="Select country" /></SelectTrigger>
              <SelectContent className="max-h-72">
                {EUROPEAN_COUNTRIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
              </SelectContent>
            </Select>
          </Field>
          <Field label="City"><Input value={city} onChange={(e) => setCity(e.target.value)} /></Field>
        </div>

        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Date"><Input type="date" value={date} onChange={(e) => setDate(e.target.value)} /></Field>
          <Field label="Distances (comma separated)">
            <Input
              value={distancesInput}
              onChange={(e) => setDistancesInput(e.target.value)}
              placeholder={SPORTS[sport].defaultDistances.join(", ")}
            />
          </Field>
        </div>

        <Field label="Description">
          <Textarea value={description} onChange={(e) => setDescription(e.target.value)} rows={4} placeholder="2–3 sentences about the race." />
        </Field>

        <Field label="Official website URL">
          <Input type="url" value={url} onChange={(e) => setUrl(e.target.value)} placeholder="https://" />
        </Field>

        <Button type="submit" size="lg" className="w-full">
          {raceType === "community" ? "Publish race" : "Submit for approval"}
        </Button>
      </form>
    </div>
  );
}

function Field({ label, children }: { label: string; children: React.ReactNode }) {
  return (
    <div className="space-y-2">
      <Label>{label}</Label>
      {children}
    </div>
  );
}
