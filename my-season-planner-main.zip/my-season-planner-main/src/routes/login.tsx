import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { useAuth } from "@/store/auth";
import { Logo } from "@/components/Logo";
import { toast } from "sonner";

export const Route = createFileRoute("/login")({
  head: () => ({ meta: [{ title: "Sign in | myseason.pro" }] }),
  component: LoginPage,
});

function LoginPage() {
  const navigate = useNavigate();
  const login = useAuth((s) => s.login);
  const signup = useAuth((s) => s.signup);

  const [loginEmail, setLoginEmail] = useState("");
  const [name, setName] = useState("");
  const [signupEmail, setSignupEmail] = useState("");

  const doLogin = (e: React.FormEvent) => {
    e.preventDefault();
    const user = login(loginEmail);
    if (!user) {
      toast.error("No account with that email. Try signing up — or use admin@myseason.pro");
      return;
    }
    toast.success(`Welcome back, ${user.name}`);
    navigate({ to: "/" });
  };

  const doSignup = (e: React.FormEvent) => {
    e.preventDefault();
    if (!name || !signupEmail) { toast.error("Add your name and email"); return; }
    const user = signup(name, signupEmail);
    toast.success(`Welcome, ${user.name}!`);
    navigate({ to: "/profile" });
  };

  return (
    <div className="min-h-[80vh] flex items-center justify-center px-4 py-10">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <Logo className="justify-center" />
          <h1 className="font-display text-2xl font-bold mt-6">Plan your race season</h1>
          <p className="text-muted-foreground text-sm mt-1">Sign in or create a free account.</p>
        </div>

        <div className="rounded-2xl border border-border bg-card p-6">
          <Tabs defaultValue="login">
            <TabsList className="grid grid-cols-2 w-full">
              <TabsTrigger value="login">Sign in</TabsTrigger>
              <TabsTrigger value="signup">Sign up</TabsTrigger>
            </TabsList>

            <TabsContent value="login" className="mt-5">
              <form onSubmit={doLogin} className="space-y-4">
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input type="email" value={loginEmail} onChange={(e) => setLoginEmail(e.target.value)} placeholder="you@example.com" />
                </div>
                <Button className="w-full">Sign in</Button>
                <p className="text-xs text-center text-muted-foreground">
                  Try <button type="button" className="underline" onClick={() => setLoginEmail("admin@myseason.pro")}>admin@myseason.pro</button> for admin access.
                </p>
              </form>
            </TabsContent>

            <TabsContent value="signup" className="mt-5">
              <form onSubmit={doSignup} className="space-y-4">
                <div className="space-y-2">
                  <Label>Name</Label>
                  <Input value={name} onChange={(e) => setName(e.target.value)} />
                </div>
                <div className="space-y-2">
                  <Label>Email</Label>
                  <Input type="email" value={signupEmail} onChange={(e) => setSignupEmail(e.target.value)} />
                </div>
                <Button className="w-full">Create account</Button>
              </form>
            </TabsContent>
          </Tabs>
        </div>

        <p className="text-xs text-center text-muted-foreground mt-6">
          By continuing you agree to our <Link to="/" className="underline">terms</Link>.
        </p>
      </div>
    </div>
  );
}
