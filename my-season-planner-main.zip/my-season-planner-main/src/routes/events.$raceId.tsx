import { createFileRoute, Link, notFound } from "@tanstack/react-router";
import { format } from "date-fns";
import { Heart, ExternalLink, MapPin, CalendarDays, ArrowLeft, Share2 } from "lucide-react";
import { useRaces } from "@/store/races";
import { useFavorites } from "@/store/favorites";
import { useCurrentUser } from "@/store/auth";
import { SPORTS, sportClasses } from "@/data/sports";
import { flagOf } from "@/data/countries";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { cn } from "@/lib/utils";
import { daysUntil } from "@/lib/dates";
import { toast } from "sonner";

export const Route = createFileRoute("/events/$raceId")({
  component: RaceDetailPage,
  notFoundComponent: () => (
    <div className="container mx-auto px-4 py-24 text-center">
      <h1 className="text-3xl font-bold">Race not found</h1>
      <Button asChild className="mt-6"><Link to="/events">Browse races</Link></Button>
    </div>
  ),
});

function RaceDetailPage() {
  const { raceId } = Route.useParams();
  const race = useRaces((s) => s.races.find((r) => r.id === raceId));
  const user = useCurrentUser();
  const fav = useFavorites((s) => s.get(user?.id, raceId));
  const toggle = useFavorites((s) => s.toggle);
  const setDistance = useFavorites((s) => s.setDistance);

  if (!race) throw notFound();

  const sport = SPORTS[race.sport_type];
  const classes = sportClasses(race.sport_type);
  const Icon = sport.icon;
  const days = daysUntil(race.date);
  const isFav = !!fav;

  const handleFav = () => {
    if (!user) { toast.error("Sign in to save races"); return; }
    toggle(user.id, race.id, race.distances[0] ?? "");
    toast.success(isFav ? "Removed from your calendar" : "Saved to your calendar");
  };

  const share = async () => {
    const url = typeof window !== "undefined" ? window.location.href : "";
    try {
      if (navigator.share) await navigator.share({ title: race.title, url });
      else { await navigator.clipboard.writeText(url); toast.success("Link copied"); }
    } catch { /* cancelled */ }
  };

  return (
    <div>
      <div className={cn("relative h-64 md:h-80 bg-gradient-to-br", classes.gradient)}>
        <div className="absolute inset-0 bg-gradient-to-t from-background via-background/40 to-transparent" />
        <div className="container mx-auto px-4 h-full relative flex flex-col justify-end pb-8">
          <Button asChild variant="ghost" size="sm" className="self-start mb-4 mt-6">
            <Link to="/events"><ArrowLeft className="w-4 h-4 mr-1" /> All races</Link>
          </Button>
          <div className="flex items-center gap-2 mb-3">
            <div className={cn("inline-flex items-center gap-1.5 px-3 py-1 rounded-full border text-xs font-medium", classes.chip)}>
              <Icon className="w-4 h-4" /> {sport.label} · {race.subcategory}
            </div>
            {race.race_type === "community" && (
              <Badge variant="outline">Community race</Badge>
            )}
          </div>
          <h1 className="font-display text-3xl md:text-5xl font-bold max-w-3xl text-balance">{race.title}</h1>
          <div className="mt-4 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-2"><CalendarDays className="w-4 h-4" /> {format(new Date(race.date), "EEEE, d MMMM yyyy")}</span>
            <span className="flex items-center gap-2"><MapPin className="w-4 h-4" /> {flagOf(race.country)} {race.city}, {race.country}</span>
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10 grid lg:grid-cols-[1fr_320px] gap-10">
        <div>
          <h2 className="font-display text-xl font-semibold mb-3">About this race</h2>
          <p className="text-muted-foreground leading-relaxed">{race.description}</p>

          <h2 className="font-display text-xl font-semibold mt-10 mb-3">Distances</h2>
          <div className="flex flex-wrap gap-2">
            {race.distances.map((d) => (
              <span key={d} className={cn("px-3 py-1.5 rounded-lg text-sm border", classes.chip)}>{d}</span>
            ))}
          </div>

          <div className="mt-10 flex flex-wrap gap-3">
            <Button asChild size="lg">
              <a href={race.official_website_url} target="_blank" rel="noreferrer">
                Go to official website <ExternalLink className="w-4 h-4 ml-1.5" />
              </a>
            </Button>
            <Button variant="outline" size="lg" onClick={share}>
              <Share2 className="w-4 h-4 mr-1.5" /> Share
            </Button>
          </div>
        </div>

        <aside>
          <div className="sticky top-20 rounded-2xl border border-border bg-card p-6 space-y-5">
            <div>
              <p className="text-xs uppercase tracking-wider text-muted-foreground">Countdown</p>
              <p className={cn("font-display text-4xl font-bold mt-1", classes.text)}>
                {days > 0 ? `${days}` : days === 0 ? "Today" : `${Math.abs(days)}d`}
              </p>
              <p className="text-sm text-muted-foreground">
                {days > 0 ? "days to go" : days === 0 ? "Race day!" : "since the race"}
              </p>
            </div>

            <Button onClick={handleFav} variant={isFav ? "secondary" : "default"} className="w-full" size="lg">
              <Heart className={cn("w-4 h-4 mr-2", isFav && "fill-current")} />
              {isFav ? "Saved to calendar" : "Save to calendar"}
            </Button>

            {isFav && user && (
              <div className="space-y-2">
                <label className="text-xs uppercase tracking-wider text-muted-foreground">Your distance</label>
                <Select
                  value={fav?.selected_distance || race.distances[0]}
                  onValueChange={(v) => setDistance(user.id, race.id, v)}
                >
                  <SelectTrigger><SelectValue /></SelectTrigger>
                  <SelectContent>
                    {race.distances.map((d) => <SelectItem key={d} value={d}>{d}</SelectItem>)}
                  </SelectContent>
                </Select>
              </div>
            )}
          </div>
        </aside>
      </div>
    </div>
  );
}
