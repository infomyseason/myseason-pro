import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo } from "react";
import { format } from "date-fns";
import { Check, X, Trash2, ArrowUpCircle } from "lucide-react";
import { useCurrentUser } from "@/store/auth";
import { useRaces } from "@/store/races";
import { SPORTS, sportClasses } from "@/data/sports";
import { flagOf } from "@/data/countries";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Badge } from "@/components/ui/badge";
import {
  Table, TableBody, TableCell, TableHead, TableHeader, TableRow,
} from "@/components/ui/table";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export const Route = createFileRoute("/admin")({
  head: () => ({ meta: [{ title: "Admin | myseason.pro" }] }),
  component: AdminPage,
});

function AdminPage() {
  const user = useCurrentUser();
  const navigate = useNavigate();
  const races = useRaces((s) => s.races);
  const setStatus = useRaces((s) => s.setStatus);
  const removeRace = useRaces((s) => s.removeRace);
  const promote = useRaces((s) => s.promoteToOfficial);

  useEffect(() => {
    if (user && user.role !== "admin") navigate({ to: "/" });
  }, [user, navigate]);

  const pending = useMemo(() => races.filter((r) => r.status === "pending"), [races]);
  const community = useMemo(
    () => races.filter((r) => r.race_type === "community" && r.status === "approved"),
    [races],
  );

  if (!user) {
    return (
      <div className="container mx-auto px-4 py-24 text-center max-w-md">
        <h1 className="font-display text-3xl font-bold">Admin area</h1>
        <p className="text-muted-foreground mt-2">Sign in as an admin to access this area.</p>
        <Button asChild className="mt-6"><Link to="/login">Sign in</Link></Button>
      </div>
    );
  }
  if (user.role !== "admin") return null;

  return (
    <div className="container mx-auto px-4 py-10">
      <h1 className="font-display text-3xl md:text-4xl font-bold">Admin</h1>
      <p className="text-muted-foreground mt-1">Review submissions, promote community races, and manage the catalog.</p>

      <Tabs defaultValue="pending" className="mt-8">
        <TabsList>
          <TabsTrigger value="pending">Pending ({pending.length})</TabsTrigger>
          <TabsTrigger value="community">Community ({community.length})</TabsTrigger>
          <TabsTrigger value="all">All races ({races.length})</TabsTrigger>
        </TabsList>

        <TabsContent value="pending" className="mt-6">
          {pending.length === 0 ? (
            <Empty message="No pending submissions." />
          ) : (
            <RaceTable
              rows={pending}
              actions={(r) => (
                <>
                  <Button size="sm" onClick={() => { setStatus(r.id, "approved"); toast.success("Race approved"); }}>
                    <Check className="w-4 h-4 mr-1" /> Approve
                  </Button>
                  <Button size="sm" variant="outline" onClick={() => { setStatus(r.id, "rejected"); toast("Race rejected"); }}>
                    <X className="w-4 h-4 mr-1" /> Reject
                  </Button>
                </>
              )}
            />
          )}
        </TabsContent>

        <TabsContent value="community" className="mt-6">
          {community.length === 0 ? (
            <Empty message="No community races yet." />
          ) : (
            <RaceTable
              rows={community}
              actions={(r) => (
                <>
                  <Button size="sm" onClick={() => { promote(r.id); toast.success("Promoted to official"); }}>
                    <ArrowUpCircle className="w-4 h-4 mr-1" /> Make official
                  </Button>
                  <Button size="sm" variant="ghost" onClick={() => { removeRace(r.id); toast("Race removed"); }}>
                    <Trash2 className="w-4 h-4" />
                  </Button>
                </>
              )}
            />
          )}
        </TabsContent>

        <TabsContent value="all" className="mt-6">
          <RaceTable
            rows={races}
            actions={(r) => (
              <Button size="sm" variant="ghost" onClick={() => { removeRace(r.id); toast("Race removed"); }}>
                <Trash2 className="w-4 h-4" />
              </Button>
            )}
          />
        </TabsContent>
      </Tabs>
    </div>
  );
}

function RaceTable({
  rows, actions,
}: { rows: import("@/lib/types").Race[]; actions: (r: import("@/lib/types").Race) => React.ReactNode }) {
  return (
    <div className="rounded-2xl border border-border bg-card overflow-x-auto">
      <Table>
        <TableHeader>
          <TableRow>
            <TableHead>Race</TableHead>
            <TableHead>Sport</TableHead>
            <TableHead>Date</TableHead>
            <TableHead>Location</TableHead>
            <TableHead>Type</TableHead>
            <TableHead>Status</TableHead>
            <TableHead className="text-right">Actions</TableHead>
          </TableRow>
        </TableHeader>
        <TableBody>
          {rows.map((r) => {
            const sc = sportClasses(r.sport_type);
            const sport = SPORTS[r.sport_type];
            const Icon = sport.icon;
            return (
              <TableRow key={r.id}>
                <TableCell>
                  <Link to="/events/$raceId" params={{ raceId: r.id }} className="font-medium hover:text-primary">{r.title}</Link>
                </TableCell>
                <TableCell>
                  <span className={cn("inline-flex items-center gap-1.5 px-2 py-0.5 rounded-md border text-xs", sc.chip)}>
                    <Icon className="w-3.5 h-3.5" /> {sport.label}
                  </span>
                </TableCell>
                <TableCell className="whitespace-nowrap">{format(new Date(r.date), "d MMM yyyy")}</TableCell>
                <TableCell className="whitespace-nowrap text-muted-foreground">{flagOf(r.country)} {r.city}</TableCell>
                <TableCell><Badge variant="outline" className="capitalize">{r.race_type}</Badge></TableCell>
                <TableCell>
                  <Badge variant={r.status === "approved" ? "default" : r.status === "pending" ? "secondary" : "destructive"} className="capitalize">
                    {r.status}
                  </Badge>
                </TableCell>
                <TableCell className="text-right">
                  <div className="flex justify-end gap-2">{actions(r)}</div>
                </TableCell>
              </TableRow>
            );
          })}
        </TableBody>
      </Table>
    </div>
  );
}

function Empty({ message }: { message: string }) {
  return <div className="rounded-2xl border border-dashed border-border p-12 text-center text-muted-foreground">{message}</div>;
}
