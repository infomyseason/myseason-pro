import { createFileRoute, Link, useNavigate } from "@tanstack/react-router";
import { useEffect, useMemo, useState } from "react";
import { Search, MapPin, Sparkles, Users, CalendarClock, ArrowRight } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { SportPills } from "@/components/SportPills";
import { RaceCard } from "@/components/RaceCard";
import { useApprovedRaces } from "@/store/races";
import { useUserLocation } from "@/store/location";
import { EUROPEAN_COUNTRIES } from "@/data/countries";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import type { SportType } from "@/lib/types";

export const Route = createFileRoute("/")({
  head: () => ({
    meta: [
      { title: "myseason.pro — Plan your season. Find races across Europe." },
      { name: "description", content: "Discover running, triathlon, cycling and HYROX races across Europe and plan your race season." },
    ],
  }),
  component: HomePage,
});

function HomePage() {
  const races = useApprovedRaces();
  const navigate = useNavigate();
  const [search, setSearch] = useState("");
  const [sports, setSports] = useState<SportType[]>([]);
  const { country, setCountry } = useUserLocation();

  // Try geolocation once
  useEffect(() => {
    if (country || typeof navigator === "undefined" || !navigator.geolocation) return;
    // Skip silently — geolocation API doesn't return a country name. We surface manual selection instead.
  }, [country]);

  const local = useMemo(() => {
    if (!country) return [];
    return races.filter((r) => r.country === country).slice(0, 8);
  }, [races, country]);

  const popular = useMemo(
    () => [...races].sort((a, b) => b.popularity_score - a.popularity_score).slice(0, 8),
    [races],
  );
  const community = useMemo(
    () => races.filter((r) => r.race_type === "community").slice(0, 8),
    [races],
  );
  const upcoming = useMemo(
    () => [...races]
      .filter((r) => new Date(r.date).getTime() >= Date.now())
      .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime())
      .slice(0, 8),
    [races],
  );

  const submitSearch = (e: React.FormEvent) => {
    e.preventDefault();
    navigate({
      to: "/events",
      search: { q: search || undefined, sport: sports.length ? sports.join(",") : undefined } as never,
    });
  };

  return (
    <div>
      {/* Hero */}
      <section className="bg-gradient-hero">
        <div className="container mx-auto px-4 py-16 md:py-24">
          <div className="max-w-3xl">
            <div className="inline-flex items-center gap-2 px-3 py-1 rounded-full bg-primary/10 border border-primary/20 text-primary text-xs font-medium mb-6">
              <Sparkles className="w-3.5 h-3.5" />
              Race discovery & season planner
            </div>
            <h1 className="font-display text-4xl md:text-6xl font-bold leading-[1.05] text-balance">
              Plan your season. <br />
              <span className="bg-gradient-to-r from-primary via-cycling to-triathlon bg-clip-text text-transparent">
                Find races across Europe.
              </span>
            </h1>
            <p className="mt-5 text-lg text-muted-foreground max-w-xl">
              Discover running, triathlon, cycling and HYROX events from Lisbon to Helsinki — and build a calendar that pushes you to your next PR.
            </p>

            <form onSubmit={submitSearch} className="mt-8 p-2 bg-card border border-border rounded-2xl flex flex-col sm:flex-row gap-2 max-w-2xl">
              <div className="flex-1 flex items-center gap-2 px-3">
                <Search className="w-5 h-5 text-muted-foreground" />
                <Input
                  value={search}
                  onChange={(e) => setSearch(e.target.value)}
                  placeholder="Search Berlin Marathon, HYROX, Ironman…"
                  className="border-0 shadow-none focus-visible:ring-0 px-0 h-11"
                />
              </div>
              <Button type="submit" size="lg" className="h-11">
                Search races
                <ArrowRight className="w-4 h-4 ml-1" />
              </Button>
            </form>

            <div className="mt-6">
              <SportPills value={sports} onChange={setSports} />
            </div>
          </div>
        </div>
      </section>

      {/* Local races */}
      <Section
        title="Local races"
        subtitle={country ? `Races in ${country}` : "Pick your country to see local events"}
        icon={MapPin}
        action={
          <Select value={country ?? "_none"} onValueChange={(v) => setCountry(v === "_none" ? null : v)}>
            <SelectTrigger className="w-[200px]"><SelectValue placeholder="Choose country" /></SelectTrigger>
            <SelectContent className="max-h-72">
              <SelectItem value="_none">Any country</SelectItem>
              {EUROPEAN_COUNTRIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
            </SelectContent>
          </Select>
        }
      >
        {country && local.length === 0 ? (
          <EmptyHint message={`No races yet in ${country}. Try another country or browse all events.`} />
        ) : country ? (
          <Grid races={local} />
        ) : (
          <EmptyHint message="Choose a country above to see races near you." />
        )}
      </Section>

      <Section title="Popular races" subtitle="The biggest events on the continent" icon={Sparkles}>
        <Grid races={popular} />
      </Section>

      <Section title="Community races" subtitle="Races created by athletes like you" icon={Users}>
        <Grid races={community} />
      </Section>

      <Section title="Upcoming races" subtitle="Soonest first — start planning" icon={CalendarClock} last>
        <Grid races={upcoming} />
      </Section>
    </div>
  );
}

function Section({
  title, subtitle, icon: Icon, action, children, last,
}: {
  title: string; subtitle: string; icon: typeof Search; action?: React.ReactNode; children: React.ReactNode; last?: boolean;
}) {
  return (
    <section className={`container mx-auto px-4 py-12 ${last ? "pb-24" : ""}`}>
      <div className="flex flex-wrap items-end justify-between gap-4 mb-6">
        <div>
          <div className="flex items-center gap-2 text-primary text-xs font-semibold uppercase tracking-wider mb-2">
            <Icon className="w-4 h-4" /> {title}
          </div>
          <h2 className="font-display text-2xl md:text-3xl font-bold">{subtitle}</h2>
        </div>
        <div className="flex items-center gap-3">
          {action}
          <Button asChild variant="ghost" size="sm">
            <Link to="/events">View all <ArrowRight className="w-4 h-4 ml-1" /></Link>
          </Button>
        </div>
      </div>
      {children}
    </section>
  );
}

function Grid({ races }: { races: ReturnType<typeof useApprovedRaces> }) {
  if (!races.length) return <EmptyHint message="No races to show right now." />;
  return (
    <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-4">
      {races.map((r) => <RaceCard key={r.id} race={r} />)}
    </div>
  );
}

function EmptyHint({ message }: { message: string }) {
  return (
    <div className="rounded-2xl border border-dashed border-border p-8 text-center text-muted-foreground">
      {message}
    </div>
  );
}
