import { createFileRoute, useNavigate } from "@tanstack/react-router";
import { useCurrentUser } from "@/store/auth";
import { ProfileView } from "@/components/ProfileView";
import { useEffect } from "react";

export const Route = createFileRoute("/profile")({
  head: () => ({ meta: [{ title: "Profile | myseason.pro" }] }),
  component: MyProfile,
});

function MyProfile() {
  const user = useCurrentUser();
  const navigate = useNavigate();
  useEffect(() => {
    if (!user) navigate({ to: "/login" });
  }, [user, navigate]);
  if (!user) return null;
  return <ProfileView userId={user.id} editable />;
}
