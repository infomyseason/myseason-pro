import { createFileRoute, Link } from "@tanstack/react-router";
import { useMemo, useState } from "react";
import { format } from "date-fns";
import { Filter, Search as SearchIcon, X } from "lucide-react";
import { Input } from "@/components/ui/input";
import { Button } from "@/components/ui/button";
import { Label } from "@/components/ui/label";
import { Checkbox } from "@/components/ui/checkbox";
import {
  Select, SelectContent, SelectItem, SelectTrigger, SelectValue,
} from "@/components/ui/select";
import { Sheet, SheetContent, SheetTrigger, SheetHeader, SheetTitle } from "@/components/ui/sheet";
import { RaceCard } from "@/components/RaceCard";
import { SportPills } from "@/components/SportPills";
import { useApprovedRaces } from "@/store/races";
import { EUROPEAN_COUNTRIES } from "@/data/countries";
import { SPORTS } from "@/data/sports";
import type { SportType, RaceType } from "@/lib/types";

interface SearchParams {
  q?: string;
  sport?: string;
  country?: string;
}

export const Route = createFileRoute("/events")({
  validateSearch: (s: Record<string, unknown>): SearchParams => ({
    q: typeof s.q === "string" ? s.q : undefined,
    sport: typeof s.sport === "string" ? s.sport : undefined,
    country: typeof s.country === "string" ? s.country : undefined,
  }),
  head: () => ({
    meta: [
      { title: "Events — Find races across Europe | myseason.pro" },
      { name: "description", content: "Search running, triathlon, cycling and HYROX races. Filter by country, date, sport and distance." },
    ],
  }),
  component: EventsPage,
});

type DateMode = "any" | "exact" | "range" | "month";

function EventsPage() {
  const initial = Route.useSearch();
  const races = useApprovedRaces();

  const [q, setQ] = useState(initial.q ?? "");
  const [sports, setSports] = useState<SportType[]>(
    initial.sport ? (initial.sport.split(",") as SportType[]) : [],
  );
  const [country, setCountry] = useState<string>(initial.country ?? "");
  const [city, setCity] = useState("");
  const [subcategory, setSubcategory] = useState<string>("");
  const [raceType, setRaceType] = useState<"all" | RaceType>("all");
  const [dateMode, setDateMode] = useState<DateMode>("any");
  const [dateFrom, setDateFrom] = useState("");
  const [dateTo, setDateTo] = useState("");
  const [dateExact, setDateExact] = useState("");
  const [month, setMonth] = useState(""); // YYYY-MM

  const subcategoryOptions = sports.length === 1 ? SPORTS[sports[0]].subcategories : [];

  const filtered = useMemo(() => {
    return races.filter((r) => {
      if (q && !r.title.toLowerCase().includes(q.toLowerCase())
        && !r.city.toLowerCase().includes(q.toLowerCase())
        && !r.country.toLowerCase().includes(q.toLowerCase())) return false;
      if (sports.length && !sports.includes(r.sport_type)) return false;
      if (country && r.country !== country) return false;
      if (city && !r.city.toLowerCase().includes(city.toLowerCase())) return false;
      if (subcategory && r.subcategory !== subcategory) return false;
      if (raceType !== "all" && r.race_type !== raceType) return false;

      const d = new Date(r.date);
      if (dateMode === "exact" && dateExact) {
        if (format(d, "yyyy-MM-dd") !== dateExact) return false;
      } else if (dateMode === "range") {
        if (dateFrom && d < new Date(dateFrom)) return false;
        if (dateTo && d > new Date(dateTo)) return false;
      } else if (dateMode === "month" && month) {
        if (format(d, "yyyy-MM") !== month) return false;
      }
      return true;
    }).sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime());
  }, [races, q, sports, country, city, subcategory, raceType, dateMode, dateExact, dateFrom, dateTo, month]);

  const clearAll = () => {
    setQ(""); setSports([]); setCountry(""); setCity(""); setSubcategory("");
    setRaceType("all"); setDateMode("any"); setDateExact(""); setDateFrom(""); setDateTo(""); setMonth("");
  };

  const filtersUI = (
    <div className="space-y-6">
      <div className="space-y-2">
        <Label>Search</Label>
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 -translate-y-1/2 w-4 h-4 text-muted-foreground" />
          <Input value={q} onChange={(e) => setQ(e.target.value)} placeholder="Race name, city…" className="pl-9" />
        </div>
      </div>

      <div className="space-y-2">
        <Label>Sport</Label>
        <SportPills value={sports} onChange={(s) => { setSports(s); setSubcategory(""); }} />
      </div>

      {subcategoryOptions.length > 0 && (
        <div className="space-y-2">
          <Label>Distance / category</Label>
          <Select value={subcategory || "_any"} onValueChange={(v) => setSubcategory(v === "_any" ? "" : v)}>
            <SelectTrigger><SelectValue /></SelectTrigger>
            <SelectContent>
              <SelectItem value="_any">Any</SelectItem>
              {subcategoryOptions.map((s) => <SelectItem key={s} value={s}>{s}</SelectItem>)}
            </SelectContent>
          </Select>
        </div>
      )}

      <div className="space-y-2">
        <Label>Country</Label>
        <Select value={country || "_any"} onValueChange={(v) => setCountry(v === "_any" ? "" : v)}>
          <SelectTrigger><SelectValue placeholder="Any country" /></SelectTrigger>
          <SelectContent className="max-h-72">
            <SelectItem value="_any">Any country</SelectItem>
            {EUROPEAN_COUNTRIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
          </SelectContent>
        </Select>
      </div>

      <div className="space-y-2">
        <Label>City</Label>
        <Input value={city} onChange={(e) => setCity(e.target.value)} placeholder="e.g. Berlin" />
      </div>

      <div className="space-y-2">
        <Label>Date</Label>
        <Select value={dateMode} onValueChange={(v) => setDateMode(v as DateMode)}>
          <SelectTrigger><SelectValue /></SelectTrigger>
          <SelectContent>
            <SelectItem value="any">Any date</SelectItem>
            <SelectItem value="exact">Exact date</SelectItem>
            <SelectItem value="range">Date range</SelectItem>
            <SelectItem value="month">Month</SelectItem>
          </SelectContent>
        </Select>
        {dateMode === "exact" && (
          <Input type="date" value={dateExact} onChange={(e) => setDateExact(e.target.value)} />
        )}
        {dateMode === "range" && (
          <div className="grid grid-cols-2 gap-2">
            <Input type="date" value={dateFrom} onChange={(e) => setDateFrom(e.target.value)} />
            <Input type="date" value={dateTo} onChange={(e) => setDateTo(e.target.value)} />
          </div>
        )}
        {dateMode === "month" && (
          <Input type="month" value={month} onChange={(e) => setMonth(e.target.value)} />
        )}
      </div>

      <div className="space-y-2">
        <Label>Race type</Label>
        <div className="grid grid-cols-3 gap-2 text-xs">
          {(["all", "official", "community"] as const).map((rt) => (
            <button
              key={rt}
              type="button"
              onClick={() => setRaceType(rt)}
              className={`px-3 py-2 rounded-lg border transition-colors capitalize ${
                raceType === rt ? "bg-primary text-primary-foreground border-primary" : "bg-card border-border hover:border-foreground/30"
              }`}
            >
              {rt}
            </button>
          ))}
        </div>
      </div>

      <Button variant="outline" onClick={clearAll} className="w-full">
        <X className="w-4 h-4 mr-2" /> Clear filters
      </Button>
    </div>
  );

  return (
    <div className="container mx-auto px-4 py-10">
      <div className="flex items-end justify-between flex-wrap gap-4 mb-8">
        <div>
          <h1 className="font-display text-3xl md:text-4xl font-bold">Browse races</h1>
          <p className="text-muted-foreground mt-1">{filtered.length} races match your filters</p>
        </div>
        <div className="md:hidden">
          <Sheet>
            <SheetTrigger asChild>
              <Button variant="outline"><Filter className="w-4 h-4 mr-2" /> Filters</Button>
            </SheetTrigger>
            <SheetContent side="left" className="w-[320px] overflow-y-auto p-6">
              <SheetHeader><SheetTitle>Filters</SheetTitle></SheetHeader>
              <div className="mt-6">{filtersUI}</div>
            </SheetContent>
          </Sheet>
        </div>
      </div>

      <div className="grid lg:grid-cols-[280px_1fr] gap-8">
        <aside className="hidden md:block">
          <div className="sticky top-20 rounded-2xl border border-border bg-card p-5">
            {filtersUI}
          </div>
        </aside>

        <div>
          {filtered.length === 0 ? (
            <div className="rounded-2xl border border-dashed border-border p-12 text-center">
              <p className="text-muted-foreground">No races match these filters.</p>
              <Button variant="link" onClick={clearAll}>Clear filters</Button>
            </div>
          ) : (
            <div className="grid grid-cols-1 sm:grid-cols-2 xl:grid-cols-3 gap-4">
              {filtered.map((r) => <RaceCard key={r.id} race={r} />)}
            </div>
          )}
          <div className="mt-8 text-center">
            <Button asChild variant="outline"><Link to="/add-race">Don't see your race? Add it</Link></Button>
          </div>
        </div>
      </div>
    </div>
  );
}
