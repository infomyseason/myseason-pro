import { Footprints, Waves, Bike, Dumbbell, type LucideIcon } from "lucide-react";
import type { SportType, Subcategory } from "@/lib/types";

export interface SportConfig {
  id: SportType;
  label: string;
  icon: LucideIcon;
  colorVar: string; // tailwind color name
  subcategories: Subcategory[];
  defaultDistances: string[];
}

export const SPORTS: Record<SportType, SportConfig> = {
  running: {
    id: "running",
    label: "Running",
    icon: Footprints,
    colorVar: "running",
    subcategories: ["5K", "10K", "Half Marathon", "Marathon", "30K", "Ultra", "Trail", "Road", "Other"],
    defaultDistances: ["5K", "10K", "Half Marathon", "Marathon"],
  },
  triathlon: {
    id: "triathlon",
    label: "Triathlon",
    icon: Waves,
    colorVar: "triathlon",
    subcategories: ["Sprint", "Olympic", "T100", "IM 70.3", "Ironman", "Local", "Other"],
    defaultDistances: ["Sprint", "Olympic", "IM 70.3", "Ironman"],
  },
  cycling: {
    id: "cycling",
    label: "Cycling",
    icon: Bike,
    colorVar: "cycling",
    subcategories: ["Road", "Gravel", "MTB", "Gran Fondo", "Time Trial", "Other"],
    defaultDistances: ["50km", "100km", "150km", "200km"],
  },
  hyrox: {
    id: "hyrox",
    label: "HYROX",
    icon: Dumbbell,
    colorVar: "hyrox",
    subcategories: ["Individual", "Doubles", "Relay", "Pro", "Open"],
    defaultDistances: ["Individual", "Doubles", "Relay", "Pro", "Open"],
  },
};

export const SPORT_LIST = Object.values(SPORTS);

export const sportClasses = (sport: SportType) => {
  const map: Record<SportType, { bg: string; text: string; border: string; ring: string; chip: string; dot: string; gradient: string }> = {
    running: {
      bg: "bg-running", text: "text-running", border: "border-running", ring: "ring-running",
      chip: "bg-running/15 text-running border-running/30",
      dot: "bg-running",
      gradient: "from-running/30 via-running/10 to-transparent",
    },
    triathlon: {
      bg: "bg-triathlon", text: "text-triathlon", border: "border-triathlon", ring: "ring-triathlon",
      chip: "bg-triathlon/15 text-triathlon border-triathlon/30",
      dot: "bg-triathlon",
      gradient: "from-triathlon/30 via-triathlon/10 to-transparent",
    },
    cycling: {
      bg: "bg-cycling", text: "text-cycling", border: "border-cycling", ring: "ring-cycling",
      chip: "bg-cycling/15 text-cycling border-cycling/30",
      dot: "bg-cycling",
      gradient: "from-cycling/30 via-cycling/10 to-transparent",
    },
    hyrox: {
      bg: "bg-hyrox", text: "text-hyrox", border: "border-hyrox", ring: "ring-hyrox",
      chip: "bg-hyrox/15 text-hyrox border-hyrox/30",
      dot: "bg-hyrox",
      gradient: "from-hyrox/30 via-hyrox/10 to-transparent",
    },
  };
  return map[sport];
};
