import { SPORT_LIST, sportClasses } from "@/data/sports";
import type { SportType } from "@/lib/types";
import { cn } from "@/lib/utils";

interface Props {
  value: SportType[] | null;
  onChange: (sports: SportType[]) => void;
  multi?: boolean;
}

export function SportPills({ value, onChange, multi = true }: Props) {
  const selected = value ?? [];
  return (
    <div className="flex flex-wrap gap-2">
      {SPORT_LIST.map((s) => {
        const c = sportClasses(s.id);
        const active = selected.includes(s.id);
        const Icon = s.icon;
        return (
          <button
            key={s.id}
            type="button"
            onClick={() => {
              if (!multi) {
                onChange(active ? [] : [s.id]);
                return;
              }
              onChange(active ? selected.filter((x) => x !== s.id) : [...selected, s.id]);
            }}
            className={cn(
              "inline-flex items-center gap-2 px-3.5 py-2 rounded-full border text-sm font-medium transition-all",
              active
                ? cn(c.chip, "border-current shadow-sm scale-[1.02]")
                : "bg-card border-border text-muted-foreground hover:text-foreground hover:border-foreground/30",
            )}
          >
            <Icon className="w-4 h-4" />
            {s.label}
          </button>
        );
      })}
    </div>
  );
}
