import { useMemo, useState } from "react";
import { Link } from "@tanstack/react-router";
import { format } from "date-fns";
import { Edit3, MapPin, Trophy, CheckCircle2 } from "lucide-react";
import { useAuth, useCurrentUser } from "@/store/auth";
import { useFavorites } from "@/store/favorites";
import { useRaces } from "@/store/races";
import { SPORTS, SPORT_LIST, sportClasses } from "@/data/sports";
import { EUROPEAN_COUNTRIES, flagOf } from "@/data/countries";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import { Dialog, DialogContent, DialogHeader, DialogTitle, DialogTrigger, DialogFooter } from "@/components/ui/dialog";
import { Input } from "@/components/ui/input";
import { Label } from "@/components/ui/label";
import { Textarea } from "@/components/ui/textarea";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { SportPills } from "@/components/SportPills";
import { RaceCard } from "@/components/RaceCard";
import { timeRemainingLabel } from "@/lib/dates";
import { cn } from "@/lib/utils";
import type { SportType } from "@/lib/types";
import { toast } from "sonner";

export function ProfileView({ userId, editable }: { userId: string; editable: boolean }) {
  const getUser = useAuth((s) => s.getUser);
  const updateUser = useAuth((s) => s.updateUser);
  const currentUser = useCurrentUser();
  const profile = getUser(userId);
  const races = useRaces((s) => s.races);
  const favs = useFavorites((s) => s.forUser(userId));
  const setCompleted = useFavorites((s) => s.setCompleted);

  const planned = useMemo(() => favs
    .filter((f) => !f.completed)
    .map((f) => races.find((r) => r.id === f.race_id))
    .filter(Boolean) as typeof races, [favs, races]);

  const completed = useMemo(() => favs
    .filter((f) => f.completed)
    .map((f) => races.find((r) => r.id === f.race_id))
    .filter(Boolean) as typeof races, [favs, races]);

  const upcomingRaces = useMemo(() => [...planned]
    .filter((r) => new Date(r.date).getTime() >= Date.now())
    .sort((a, b) => new Date(a.date).getTime() - new Date(b.date).getTime()), [planned]);

  const sportsParticipated = useMemo(() => {
    const set = new Set<SportType>();
    [...planned, ...completed].forEach((r) => set.add(r.sport_type));
    return Array.from(set);
  }, [planned, completed]);

  if (!profile) {
    return <div className="container mx-auto px-4 py-24 text-center">User not found.</div>;
  }

  const isOwn = editable && currentUser?.id === profile.id;
  const nextRace = upcomingRaces[0];

  return (
    <div>
      <div className="bg-gradient-hero">
        <div className="container mx-auto px-4 py-12">
          <div className="flex flex-col md:flex-row gap-6 items-start md:items-center">
            <Avatar className="w-24 h-24 border-4 border-card">
              <AvatarImage src={profile.avatar} />
              <AvatarFallback>{profile.name.charAt(0)}</AvatarFallback>
            </Avatar>
            <div className="flex-1">
              <h1 className="font-display text-3xl md:text-4xl font-bold">{profile.name}</h1>
              {(profile.country || profile.city) && (
                <p className="text-muted-foreground flex items-center gap-1.5 mt-1">
                  <MapPin className="w-4 h-4" /> {flagOf(profile.country)} {[profile.city, profile.country].filter(Boolean).join(", ")}
                </p>
              )}
              {profile.bio && <p className="mt-3 text-foreground/80 max-w-2xl">{profile.bio}</p>}
              <div className="flex flex-wrap gap-2 mt-4">
                {profile.favorite_sports.map((s) => {
                  const c = sportClasses(s);
                  const Icon = SPORTS[s].icon;
                  return (
                    <span key={s} className={cn("inline-flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs", c.chip)}>
                      <Icon className="w-3.5 h-3.5" /> {SPORTS[s].label}
                    </span>
                  );
                })}
              </div>
            </div>
            {isOwn && <EditProfileDialog />}
          </div>

          <div className="grid grid-cols-2 md:grid-cols-4 gap-3 mt-8">
            <Stat label="Planned races" value={planned.length} />
            <Stat label="Completed" value={completed.length} />
            <Stat label="Sports" value={sportsParticipated.length} />
            <Stat
              label="Next race"
              value={nextRace ? timeRemainingLabel(nextRace.date) : "—"}
              hint={nextRace?.title}
            />
          </div>
        </div>
      </div>

      <div className="container mx-auto px-4 py-10">
        <Tabs defaultValue="planned">
          <TabsList>
            <TabsTrigger value="planned">Planned ({planned.length})</TabsTrigger>
            <TabsTrigger value="completed">Completed ({completed.length})</TabsTrigger>
          </TabsList>

          <TabsContent value="planned" className="mt-6">
            {planned.length === 0 ? (
              <Empty message={isOwn ? "No races planned yet." : `${profile.name} has no planned races.`} cta={isOwn} />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {planned.map((r) => (
                  <div key={r.id} className="space-y-2">
                    <RaceCard race={r} />
                    {isOwn && (
                      <Button size="sm" variant="outline" className="w-full"
                        onClick={() => { setCompleted(profile.id, r.id, true); toast.success("Marked as completed"); }}>
                        <CheckCircle2 className="w-4 h-4 mr-2" /> Mark as completed
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </TabsContent>

          <TabsContent value="completed" className="mt-6">
            {completed.length === 0 ? (
              <Empty message="No completed races yet." cta={false} />
            ) : (
              <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-3 gap-4">
                {completed.map((r) => (
                  <div key={r.id} className="space-y-2">
                    <RaceCard race={r} />
                    {isOwn && (
                      <Button size="sm" variant="ghost" className="w-full"
                        onClick={() => setCompleted(profile.id, r.id, false)}>
                        Move back to planned
                      </Button>
                    )}
                  </div>
                ))}
              </div>
            )}
          </TabsContent>
        </Tabs>
      </div>
    </div>
  );
}

function Stat({ label, value, hint }: { label: string; value: string | number; hint?: string }) {
  return (
    <div className="rounded-2xl border border-border bg-card p-4">
      <div className="text-xs uppercase tracking-wider text-muted-foreground">{label}</div>
      <div className="font-display text-2xl font-bold mt-1 flex items-center gap-2">
        <Trophy className="w-5 h-5 text-primary" /> {value}
      </div>
      {hint && <div className="text-xs text-muted-foreground mt-1 truncate">{hint}</div>}
    </div>
  );
}

function Empty({ message, cta }: { message: string; cta: boolean }) {
  return (
    <div className="rounded-2xl border border-dashed border-border p-12 text-center">
      <p className="text-muted-foreground">{message}</p>
      {cta && <Button asChild className="mt-4"><Link to="/events">Find races</Link></Button>}
    </div>
  );
}

function EditProfileDialog() {
  const user = useCurrentUser()!;
  const updateUser = useAuth((s) => s.updateUser);
  const [open, setOpen] = useState(false);
  const [name, setName] = useState(user.name);
  const [country, setCountry] = useState(user.country);
  const [city, setCity] = useState(user.city);
  const [bio, setBio] = useState(user.bio);
  const [sports, setSports] = useState<SportType[]>(user.favorite_sports);

  const save = () => {
    updateUser({ name, country, city, bio, favorite_sports: sports });
    setOpen(false);
    toast.success("Profile updated");
  };

  return (
    <Dialog open={open} onOpenChange={setOpen}>
      <DialogTrigger asChild>
        <Button variant="outline"><Edit3 className="w-4 h-4 mr-2" /> Edit profile</Button>
      </DialogTrigger>
      <DialogContent className="max-w-lg">
        <DialogHeader><DialogTitle>Edit profile</DialogTitle></DialogHeader>
        <div className="space-y-4">
          <div className="space-y-2"><Label>Name</Label><Input value={name} onChange={(e) => setName(e.target.value)} /></div>
          <div className="grid grid-cols-2 gap-3">
            <div className="space-y-2">
              <Label>Country</Label>
              <Select value={country || "_none"} onValueChange={(v) => setCountry(v === "_none" ? "" : v)}>
                <SelectTrigger><SelectValue placeholder="—" /></SelectTrigger>
                <SelectContent className="max-h-72">
                  <SelectItem value="_none">—</SelectItem>
                  {EUROPEAN_COUNTRIES.map((c) => <SelectItem key={c} value={c}>{c}</SelectItem>)}
                </SelectContent>
              </Select>
            </div>
            <div className="space-y-2"><Label>City</Label><Input value={city} onChange={(e) => setCity(e.target.value)} /></div>
          </div>
          <div className="space-y-2"><Label>Bio</Label><Textarea value={bio} onChange={(e) => setBio(e.target.value)} rows={3} /></div>
          <div className="space-y-2">
            <Label>Favorite sports</Label>
            <SportPills value={sports} onChange={setSports} />
          </div>
        </div>
        <DialogFooter><Button onClick={save}>Save changes</Button></DialogFooter>
      </DialogContent>
    </Dialog>
  );
}
