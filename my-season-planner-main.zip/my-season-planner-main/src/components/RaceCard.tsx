import { Link } from "@tanstack/react-router";
import { Heart, Calendar as CalendarIcon, MapPin } from "lucide-react";
import { format } from "date-fns";
import type { Race } from "@/lib/types";
import { SPORTS, sportClasses } from "@/data/sports";
import { flagOf } from "@/data/countries";
import { useFavorites } from "@/store/favorites";
import { useCurrentUser } from "@/store/auth";
import { timeRemainingLabel } from "@/lib/dates";
import { Badge } from "@/components/ui/badge";
import { cn } from "@/lib/utils";
import { toast } from "sonner";

export function RaceCard({ race }: { race: Race }) {
  const sport = SPORTS[race.sport_type];
  const classes = sportClasses(race.sport_type);
  const Icon = sport.icon;
  const user = useCurrentUser();
  const isFav = useFavorites((s) => s.has(user?.id, race.id));
  const toggle = useFavorites((s) => s.toggle);

  const handleFav = (e: React.MouseEvent) => {
    e.preventDefault();
    e.stopPropagation();
    if (!user) {
      toast.error("Sign in to save races to your calendar");
      return;
    }
    toggle(user.id, race.id, race.distances[0] ?? "");
    toast.success(isFav ? "Removed from your calendar" : "Saved to your calendar");
  };

  return (
    <Link
      to="/events/$raceId"
      params={{ raceId: race.id }}
      className="group block rounded-2xl bg-card border border-border overflow-hidden hover:border-primary/50 hover:-translate-y-0.5 transition-all duration-300"
    >
      <div className={cn("relative h-28 bg-gradient-to-br", classes.gradient)}>
        <div className="absolute inset-0 bg-gradient-to-t from-card to-transparent" />
        <div className="absolute top-3 left-3 right-3 flex items-start justify-between">
          <div className={cn("flex items-center gap-1.5 px-2.5 py-1 rounded-full border text-xs font-medium", classes.chip)}>
            <Icon className="w-3.5 h-3.5" />
            {sport.label}
          </div>
          <button
            onClick={handleFav}
            aria-label={isFav ? "Remove favorite" : "Add favorite"}
            className="grid place-items-center w-8 h-8 rounded-full bg-background/70 backdrop-blur hover:bg-background transition-colors"
          >
            <Heart className={cn("w-4 h-4 transition-colors", isFav ? "fill-hyrox text-hyrox" : "text-muted-foreground")} />
          </button>
        </div>
        <div className="absolute bottom-2 left-3">
          {race.race_type === "community" && (
            <Badge variant="outline" className="bg-background/70 backdrop-blur text-xs">Community</Badge>
          )}
        </div>
      </div>
      <div className="p-4 space-y-3">
        <h3 className="font-display font-semibold text-base leading-tight line-clamp-2 group-hover:text-primary transition-colors">
          {race.title}
        </h3>
        <div className="flex flex-wrap gap-3 text-xs text-muted-foreground">
          <span className="flex items-center gap-1.5">
            <CalendarIcon className="w-3.5 h-3.5" />
            {format(new Date(race.date), "d MMM yyyy")}
          </span>
          <span className="flex items-center gap-1.5">
            <MapPin className="w-3.5 h-3.5" />
            {flagOf(race.country)} {race.city}
          </span>
        </div>
        <div className="flex items-center justify-between gap-2">
          <div className="flex flex-wrap gap-1.5">
            {race.distances.slice(0, 3).map((d) => (
              <span key={d} className="text-[11px] px-2 py-0.5 rounded-md bg-secondary text-secondary-foreground">
                {d}
              </span>
            ))}
          </div>
          <span className="text-xs font-semibold text-primary">{timeRemainingLabel(race.date)}</span>
        </div>
      </div>
    </Link>
  );
}
