import { Link } from "@tanstack/react-router";
import { Trophy } from "lucide-react";

export function Logo({ className = "" }: { className?: string }) {
  return (
    <Link to="/" className={`flex items-center gap-2 font-display font-bold text-lg ${className}`}>
      <span className="grid place-items-center w-8 h-8 rounded-xl bg-primary text-primary-foreground">
        <Trophy className="w-4 h-4" />
      </span>
      <span>
        myseason<span className="text-primary">.pro</span>
      </span>
    </Link>
  );
}
