import { Link, useRouterState } from "@tanstack/react-router";
import { Calendar, Home, Plus, Search, Shield, User as UserIcon, LogOut } from "lucide-react";
import { Logo } from "./Logo";
import { useAuth, useCurrentUser } from "@/store/auth";
import { Button } from "@/components/ui/button";
import {
  DropdownMenu, DropdownMenuContent, DropdownMenuItem,
  DropdownMenuLabel, DropdownMenuSeparator, DropdownMenuTrigger,
} from "@/components/ui/dropdown-menu";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";

const NAV = [
  { to: "/events", label: "Events", icon: Search },
  { to: "/calendar", label: "Calendar", icon: Calendar },
  { to: "/add-race", label: "Add Race", icon: Plus },
] as const;

export function NavBar() {
  const user = useCurrentUser();
  const logout = useAuth((s) => s.logout);
  const path = useRouterState({ select: (r) => r.location.pathname });

  return (
    <>
      <header className="sticky top-0 z-40 border-b border-border bg-background/80 backdrop-blur-xl">
        <div className="container mx-auto px-4 h-16 flex items-center justify-between gap-4">
          <Logo />
          <nav className="hidden md:flex items-center gap-1">
            {NAV.map((item) => (
              <Link
                key={item.to}
                to={item.to}
                className="px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-colors data-[active]:text-foreground data-[active]:bg-accent"
                data-active={path.startsWith(item.to) || undefined}
              >
                {item.label}
              </Link>
            ))}
            {user?.role === "admin" && (
              <Link
                to="/admin"
                className="px-3 py-2 rounded-lg text-sm font-medium text-muted-foreground hover:text-foreground hover:bg-accent transition-colors data-[active]:text-foreground data-[active]:bg-accent"
                data-active={path.startsWith("/admin") || undefined}
              >
                Admin
              </Link>
            )}
          </nav>
          <div className="flex items-center gap-2">
            {user ? (
              <DropdownMenu>
                <DropdownMenuTrigger asChild>
                  <button className="flex items-center gap-2 rounded-full hover:bg-accent p-1 pr-3 transition-colors">
                    <Avatar className="w-8 h-8">
                      <AvatarImage src={user.avatar} />
                      <AvatarFallback>{user.name.charAt(0)}</AvatarFallback>
                    </Avatar>
                    <span className="hidden sm:block text-sm font-medium">{user.name}</span>
                  </button>
                </DropdownMenuTrigger>
                <DropdownMenuContent align="end" className="w-56">
                  <DropdownMenuLabel>{user.email}</DropdownMenuLabel>
                  <DropdownMenuSeparator />
                  <DropdownMenuItem asChild>
                    <Link to="/profile"><UserIcon className="w-4 h-4 mr-2" /> My Profile</Link>
                  </DropdownMenuItem>
                  <DropdownMenuItem asChild>
                    <Link to="/calendar"><Calendar className="w-4 h-4 mr-2" /> My Calendar</Link>
                  </DropdownMenuItem>
                  {user.role === "admin" && (
                    <DropdownMenuItem asChild>
                      <Link to="/admin"><Shield className="w-4 h-4 mr-2" /> Admin</Link>
                    </DropdownMenuItem>
                  )}
                  <DropdownMenuSeparator />
                  <DropdownMenuItem onClick={logout}>
                    <LogOut className="w-4 h-4 mr-2" /> Sign out
                  </DropdownMenuItem>
                </DropdownMenuContent>
              </DropdownMenu>
            ) : (
              <Button asChild size="sm" variant="default">
                <Link to="/login">Sign in</Link>
              </Button>
            )}
          </div>
        </div>
      </header>

      {/* Mobile bottom nav */}
      <nav className="md:hidden fixed bottom-0 left-0 right-0 z-40 border-t border-border bg-background/95 backdrop-blur-xl">
        <div className="grid grid-cols-4">
          <MobileTab to="/" label="Home" icon={Home} active={path === "/"} />
          {NAV.map((item) => (
            <MobileTab
              key={item.to}
              to={item.to}
              label={item.label}
              icon={item.icon}
              active={path.startsWith(item.to)}
            />
          ))}
        </div>
      </nav>
    </>
  );
}

function MobileTab({
  to, label, icon: Icon, active,
}: { to: string; label: string; icon: typeof Home; active: boolean }) {
  return (
    <Link
      to={to}
      className={`flex flex-col items-center justify-center gap-1 py-2.5 text-xs ${
        active ? "text-primary" : "text-muted-foreground"
      }`}
    >
      <Icon className="w-5 h-5" />
      {label}
    </Link>
  );
}
