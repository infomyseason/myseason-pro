
# myseason.pro — Race Discovery & Season Planner

A premium, sporty platform for discovering races across Europe (excl. Russia & Belarus) and building a personal season calendar. MVP runs on mock data + mock auth; structured so a real database can drop in later.

## Design system

- **Palette**: dark navy `#0B1220` background, white surfaces, accent greens/purples/blues/pinks per sport.
  - Running → green, Triathlon → purple, Cycling → blue, HYROX → pink/orange
- **Type**: Space Grotesk (headings) + Inter (body) — clean, modern, sporty SaaS.
- **UI**: rounded-2xl cards, soft shadows, sport-colored chips/icons (Lucide), subtle motion (fade/slide on scroll, hover lift, countdown pulse).
- **Responsive**: mobile-first, sticky bottom nav on mobile, table → card view on small screens.

## Pages & routes

```text
/                       Home
/events                 Race search with filters
/events/$raceId         Race detail
/add-race               Submit a race (auth)
/calendar               My Calendar (auth)
/profile/$userId        Public profile
/profile                Own profile / edit (auth)
/admin                  Admin approval queue (admin only)
/login                  Mock login/signup
```

Shared layout: top nav (logo, Events, Calendar, Add Race, Profile, Login/Avatar). Mobile: hamburger + bottom tab bar.

### Home
- Hero: "Plan your season. Find races across Europe." + search bar + 4 sport quick-filter pills.
- Sections (horizontal scroll on mobile, grid on desktop):
  - **Local races** — geolocation prompt; fallback to country dropdown (stored in localStorage).
  - **Popular races** — sorted by `popularity_score`.
  - **Community races** — `race_type = community`.
  - **Upcoming races** — nearest dates first.

### Events page
Sidebar/drawer filters: country (multi), city (text), date (exact / range / month-only toggle), sport (multi), subcategory (depends on sport), distance, race type (official/community). Results as race cards with sport color accent, country flag, date, distance chips, heart button.

### Race detail
Hero with sport-colored gradient, title, date, location, distance chips, description (2–3 sentences), "Visit official website" CTA, heart/favorite, distance selector (saved with favorite), countdown ("42 days to go"), share button. Community races labeled with badge.

### Add race
Form: title, sport (drives subcategory options), country, city, date, distances (multi-select), description, official URL, type radio: **Official** (→ pending admin) or **Community** (→ instant publish). Toast confirmation.

### My Calendar (auth)
Table columns: Date · Race · Sport · Location · Selected distance · Time remaining · Actions (remove / change distance / open). Chronological. Mobile = stacked cards. **Download** button: PDF (jsPDF) or PNG (html-to-image).

### Profile
Strava-style header: avatar, name, country/city, bio, favorite sport chips. Stats row: total planned, completed, sports count, next race countdown. Tabs: Planned · Completed. Edit button only on own profile.

### Admin
Tabs: **Pending official** (approve/reject), **All races** (edit/delete), **Community → Official** (promote). Visible only when mock user has `role: admin`.

## Mock data & state

- `src/data/races.ts` — seed with: Berlin Marathon, Vilnius Marathon, Kaunas Half Marathon, Ironman 70.3 Tallinn, HYROX Katowice, Trakai Triathlon, Tour de France stage, community trail race + ~15 more across European countries for filter realism.
- `src/data/countries.ts` — full European list excluding Russia & Belarus.
- `src/data/sports.ts` — sport → subcategories map + color tokens + icon.
- **Auth**: mock provider in React context, persisted to localStorage. Pre-seeded users incl. one admin. Login screen accepts any email; signup creates a local user.
- **State**: Zustand stores for `auth`, `races`, `favorites` (with selected distance per race) — all persisted to localStorage so the app behaves like a real product across reloads.

## Data model (TypeScript types, ready for DB swap)

```text
Race { id, title, sport_type, subcategory, country, city, date,
       distances[], description, official_website_url,
       race_type: 'official'|'community',
       status: 'pending'|'approved'|'rejected',
       popularity_score, created_by, created_at }

User { id, name, avatar, country, city, bio,
       favorite_sports[], role: 'user'|'admin' }

Favorite { user_id, race_id, selected_distance, completed: bool }
```

## Out of scope (MVP)
- Real backend / Lovable Cloud (mock only this round; easy to wire later).
- Real OAuth, payments, email.
- Multi-language.

## Tech notes
- TanStack Start file routes per page (separate routes, not hash anchors).
- Lucide icons, shadcn/ui (cards, dialog, drawer, tabs, table, select, popover, calendar).
- jsPDF + html-to-image for calendar export.
- date-fns for countdowns and formatting.

After approval I'll scaffold routes, seed mock data, build components, and wire favorites + calendar export end-to-end.
